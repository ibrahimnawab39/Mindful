
<?php $__env->startSection('pagename','Dashboard'); ?>
<?php $__env->startSection('styles'); ?>
<style>
     :root {
     --background-body: #fff;
         
     }
     
[theme="darkTheme"] {
    --background-body: #121212;
    
}
 
 </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
 
    <section class='dashboard-section'>
        <div class='deahboardSecLeft col-md-5 col-lg-6 '>
            <h1>Connecting  Minds</h1>
            <p>Mindful is a social networking application that encourages lively debates on a range of topics, with an emphasis on religion and science. Users can engage in random video or text chats to challenge their perspectives, promote critical thinking, and foster common understanding to build a community of passionate and intellectually curious individuals.</p>
            
            <button class='btn btn-light-dark rounded-pill btn-small'>Start Chatting</button>
            <div class='dashboardbtngrp'>
                <button class='btn btn-light-dark rounded '>Text</button>
                <a class='btn btn-dark rounded ' href="<?php echo e(route('front.video')); ?>">Video</a>
            </div>
        </div>
        <div class='deahboardSecRight col-md-5 col-lg-6 '>
            
            <div class=' dashpoardslider'>
                <img src="<?php echo e(asset('assets/images/slider/02.svg')); ?>" >
                <img src="<?php echo e(asset('assets/images/slider/02.svg')); ?>" >
                <img src="<?php echo e(asset('assets/images/slider/02.svg')); ?>" > 
            </div>
            <p>
                Chat GPT: Generative Pre-trained Transformer for Open-Domain Conversational AI
            </p>
             <button class='btn btn-dark rounded '>Open GPT</button>
        </div>
    </section>
   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u958043154/domains/xiomstudio.com/public_html/mindful/resources/views/front/index.blade.php ENDPATH**/ ?>